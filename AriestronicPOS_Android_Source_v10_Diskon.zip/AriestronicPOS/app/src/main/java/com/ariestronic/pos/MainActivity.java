package com.ariestronic.pos;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import android.widget.Toast;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity {
    private WebView web;
    private static final int REQ_BT = 41;
    private String pendingText = null;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int REQ_FILE = 42;
    private final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Window w=getWindow(); w.setStatusBarColor(android.graphics.Color.rgb(57,134,83));
        w.setNavigationBarColor(android.graphics.Color.WHITE);
        w.getDecorView().setSystemUiVisibility(android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        web=new WebView(this); WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true); s.setDatabaseEnabled(true); s.setAllowFileAccess(true);
        s.setAllowContentAccess(true); s.setSupportZoom(false); s.setBuiltInZoomControls(false);
        web.addJavascriptInterface(new PrinterBridge(),"AriesPrinter");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                try { startActivityForResult(Intent.createChooser(intent, "Pilih file backup ARIESTRONIC"), REQ_FILE); }
                catch (Exception e) { filePathCallback = null; callback.onReceiveValue(null); return false; }
                return true;
            }
        });
        web.setBackgroundColor(android.graphics.Color.rgb(245,248,245)); setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private class PrinterBridge {
        @JavascriptInterface public void print(String text, int paperWidth) { runOnUiThread(() -> choosePrinter(text)); }
        @JavascriptInterface public void toast(String text) { runOnUiThread(() -> Toast.makeText(MainActivity.this,text,Toast.LENGTH_LONG).show()); }
    }

    private void choosePrinter(String text) {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED) {
            pendingText=text; requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},REQ_BT); return;
        }
        BluetoothAdapter adapter=BluetoothAdapter.getDefaultAdapter();
        if(adapter==null){toast("HP tidak mendukung Bluetooth.");return;}
        if(!adapter.isEnabled()){toast("Aktifkan Bluetooth terlebih dahulu.");return;}
        try {
            Set<BluetoothDevice> bonded=adapter.getBondedDevices(); ArrayList<BluetoothDevice> list=new ArrayList<>(bonded);
            if(list.isEmpty()){toast("Pairing printer Bluetooth melalui Pengaturan HP terlebih dahulu.");return;}
            String[] names=new String[list.size()]; for(int i=0;i<list.size();i++) names[i]=list.get(i).getName()+"\n"+list.get(i).getAddress();
            new AlertDialog.Builder(this).setTitle("Pilih Printer Bluetooth").setItems(names,(d,which)->sendToPrinter(list.get(which),text)).setNegativeButton("Batal",null).show();
        } catch(SecurityException e){toast("Izin Bluetooth belum diberikan.");}
    }
    private void sendToPrinter(BluetoothDevice device,String text) {
        new Thread(() -> {
            BluetoothSocket socket=null;
            try {
                socket=device.createRfcommSocketToServiceRecord(SPP); socket.connect(); OutputStream out=socket.getOutputStream();
                out.write(new byte[]{0x1B,0x40}); out.write(text.getBytes(Charset.forName("CP437")));
                out.write(new byte[]{0x0A,0x0A,0x0A,0x1D,0x56,0x00}); out.flush(); socket.close();
                runOnUiThread(()->toast("Struk dikirim ke printer."));
            } catch(Exception e){try{if(socket!=null)socket.close();}catch(Exception ignored){} runOnUiThread(()->toast("Gagal mencetak. Pastikan printer menyala dan sudah dipasangkan."));}
        }).start();
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] results){super.onRequestPermissionsResult(requestCode,permissions,results);if(requestCode==REQ_BT){if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED&&pendingText!=null){String t=pendingText;pendingText=null;choosePrinter(t);}else toast("Izin Bluetooth diperlukan untuk mencetak.");}}
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE && filePathCallback != null) {
            Uri[] result = (resultCode == RESULT_OK && data != null && data.getData() != null) ? new Uri[]{data.getData()} : null;
            filePathCallback.onReceiveValue(result);
            filePathCallback = null;
        }
    }
    @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
}
