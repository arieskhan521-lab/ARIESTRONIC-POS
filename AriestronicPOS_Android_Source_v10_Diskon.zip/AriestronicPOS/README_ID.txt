ARIESTRONIC POS V9 - OFFLINE ANDROID

Pembaruan V9:
- Harga jual eceran dan harga grosir pada master produk.
- Pilihan jenis harga transaksi di halaman POS.
- Harga yang dipilih disimpan pada item transaksi dan dipakai menghitung total, laba, serta struk.
- Produk lama yang belum memiliki harga grosir tetap memakai harga eceran saat mode grosir dipilih.
- Fitur V8 tetap dipertahankan: tema hijau muda, satuan produk, pengaturan printer 58/80 mm, service elektronik, backup lokal.

Build:
1. Ekstrak ZIP ini.
2. Unggah ISI folder AriestronicPOS ke root repository GitHub (bukan file ZIP saja).
3. Pastikan workflow berada di .github/workflows/build-apk.yml di root repository.
4. Jalankan Actions dan unduh artifact APK.

Catatan: Ini source proyek Android. APK perlu dibuild melalui GitHub Actions dan diuji pada perangkat serta printer Bluetooth. Data aplikasi tersimpan lokal; lakukan backup secara berkala.


V10 - DISKON: Diskon per barang berupa nominal rupiah per satuan, serta diskon total transaksi berupa persentase atau nominal. Diskon dibatasi agar tidak melebihi nilai barang/transaksi. Struk menampilkan subtotal, diskon, dan total bayar.
